import keyboard
keyboard.add_hotkey('Ctrl + 1', lambda: print('123'))
print('I r')
input()
