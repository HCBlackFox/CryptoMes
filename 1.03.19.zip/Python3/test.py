import os


os.system('cls')
def login():
    print('''
______________________________
|                            |
| /  _  _  ._     _/__       |
|/_,/_//_/// /    / /_/      |
|      _/                    |
|       _                    |
|      /_/_  _  _     _ _/_  |
|     / //_ /_ /_//_// //    |
-----------------------------|                          ''')
    input('''|Username:                   |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b''')
    input('''|Password:                   |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b''')

login()