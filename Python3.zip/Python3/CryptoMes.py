from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import binascii, re, hashlib, urllib.request, urllib.parse, urllib.error, urllib.request, urllib.error, urllib.parse, os, sys, time
import threading

def keygen():
			
			privatekey = RSA.generate(2048)
			f = open('privatekey.txt','wb')
			f.write(bytes(privatekey.exportKey('PEM'))); f.close()
			publickey = privatekey.publickey()
			f = open('publickey.txt','wb')
			f.write(bytes(publickey.exportKey('PEM'))); f.close()
			print("Keys generate succesfuly :)")
			pass


def crypt(data):
			publickey = RSA.importKey(open("xpublickey.txt",'rb').read())
			cipherrsa = PKCS1_OAEP.new(publickey)
			secdata = cipherrsa.encrypt(data.encode("utf-8"))
			#secdata = ":".join("{:02x}".format(ord(c)) for c in secdata)
			return secdata





def decrypt(secdata):
			#secdata = binascii.unhexlify(re.sub(':', '',secdata))
			privatekey = RSA.importKey(open('privatekey.txt','rb').read())
			cipherrsa = PKCS1_OAEP.new(privatekey)
			decdata = cipherrsa.decrypt(secdata)
			return decdata



def receivepub(nick):
			
			name =  "1"
			data = {"user" : nick}
			
			encoded_data = urllib.parse.urlencode(data).encode("utf-8")
			content = urllib.request.urlopen(c7,
		        encoded_data)		
			
			pubsite = urllib.request.urlopen(c4)
			pubkey = pubsite.read()
			
			f = open('xpublickey.txt','wb')
			f.write(bytes(pubkey)); f.close();



def sendpub(nick,password):
			mypub = open('publickey.txt','rb')
			
			name =  "1"
			data = {"pub" : mypub.read(), "nick" : nick, "pass" : password}
			
			encoded_data = urllib.parse.urlencode(data).encode("utf-8")
			content = urllib.request.urlopen(c1,
		        encoded_data)	
			

def wait(c6,renick):
	try:
		mes = urllib.request.urlopen(c6)
		h = hash(mes.read())
		while True:
			mes = urllib.request.urlopen(c6)
			h2 = urllib.request.urlopen(c6).read()
			if h != h2:
				decmes = decrypt(mes.read()).decode()
				print ("\n" + renick + ":" + decmes )
				h = h2
	except:
		time.sleep(5)
		wait(c6,renick)
	
def startmes():
	secdata = crypt("Hey send me message!:)")
	name =  "1"
	data = {"message" : secdata , "nick" : nick }		
	encoded_data = urllib.parse.urlencode(data).encode("utf-8")
	content = urllib.request.urlopen(c5,
	encoded_data)


def sendmessage(nick,c5):
		while True:
			
			secdata = crypt(input('You:'))
			name =  "1"
			data = {"message" : secdata , "nick" : nick }
			
			encoded_data = urllib.parse.urlencode(data).encode("utf-8")
			content = urllib.request.urlopen(c5,
	        	encoded_data)





#___________________________________________________________________________________________________________________________
if __name__ == "__main__": 


			nick = input('What is your nickname? \n:>')

			password = input('What is your password? \n:>')

			renick = input("What is your recipient's nickname\n:>") 

			key = input("Generate RSA keys? \n:>")

			if key == '1':
				keygen()


			#sys = raw_input("Which channel to use?(1/2) \n:>")
			#if sys == '1':
			c1 = "http://hcbf.000webhostapp.com/RSA/pubrecord.php"#1
			c2 = "http://hcbf.000webhostapp.com/RSA/chatid.php"#1
			c3 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
			c4 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
			c5 = "http://hcbf.000webhostapp.com/RSA/message.php"#-
			c6 = "http://hcbf.000webhostapp.com/RSA/message" + renick + ".txt"
			c7 = "http://hcbf.000webhostapp.com/RSA/keyexchange.php"
			'''
			if sys == '2':
					c1 = "http://hcbf.000webhostapp.com/RSA2/pubrecord.php"
					c2 = "http://hcbf.000webhostapp.com/RSA2/chatid.php"
					c3 = "http://hcbf.000webhostapp.com/RSA2/publickey.txt"
					c4 = "http://hcbf.000webhostapp.com/RSA2/publickey.txt"
					c5 = "http://hcbf.000webhostapp.com/RSA2/message.php"
					c6 = "http://hcbf.000webhostapp.com/RSA2/message" + renick + ".txt"
					c7 = "http://hcbf.000webhostapp.com/RSA2/keyexchange.php"
			'''

			key = input("You want to send publickey? \n:>")

			if key == '1':
				sendpub(nick,password)

			key = input("You want to receive publickey? \n:>")

			if key == '1':
					receivepub(renick)
			startmes()
			
			t1 = threading.Thread(target=sendmessage, args=(nick,c5 ))
			t2 = threading.Thread(target=wait, args=(c6,renick ))
    
			t1.start()
			t2.start()

