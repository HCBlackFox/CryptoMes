from Crypto.Cipher import PKCS1_OAEP; from Crypto.PublicKey import RSA
from win10toast import ToastNotifier; from pyautogui import hotkey

import urllib.request, urllib.error, urllib.parse
import keyboard, shutil, sys, time, threading, os, binascii, hashlib
import TUI as tui

global DIR, name, stop, toaster, c1, c2, c3, c4, c5

stop = False; toaster = ToastNotifier(); DIR = "Dialogues/"; name =  "1"; c1 = "http://hcbf.000webhostapp.com/RSA/pubrecord.php"; c2 = "http://hcbf.000webhostapp.com/RSA/"; c3 = "http://hcbf.000webhostapp.com/RSA/message.php"; c4 = "http://hcbf.000webhostapp.com/RSA/keyexchange.php"; c5 = None; end ='\n|--:>                                 |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b'; b1 ='\b\b\b\b\b\b\b|'; b2 ='                                     |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b';inp = '|--:>                                 |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b';

#-----------------------------------------------------------------------------------------------
#Key operations
#-----------------------------------------------------------------------------------------------

def keygen():
        if os.path.isdir('Sessions'):
            shutil.copy('privatekey.txt','Sessions/privatekey.txt')
        else:
            os.mkdir('Sessions')
            shutil.copy('privatekey.txt','Sessions/privatekey.txt')


        privatekey = RSA.generate(2048)

        f = open('privatekey.txt','wb')
        f.write(bytes(privatekey.exportKey('PEM'))); f.close()

        publickey = privatekey.publickey()

        f = open('publickey.txt','wb')
        f.write(bytes(publickey.exportKey('PEM'))); f.close()

        print("Keypair generate succesfuly :)")
        pass

def receivepub(renick):
        f = open(DIR + str(renick) + "\\xpublickey.txt" , 'wb')

        data = {"user" : renick}
        content = urllib.request.urlopen(c4,urllib.parse.urlencode(data).encode("utf-8"))
        pubsite = urllib.request.urlopen(c2 + renick + "/publickey.txt")

        f.write(pubsite.read())
        pass

def sendpub(nick,password):
        pub = open('publickey.txt','rb')
        data = {"pub" : pub.read(), "nick" : nick, "pass" : hashlib.sha1(password.encode('utf-8')).hexdigest()}
        content = urllib.request.urlopen(c1,urllib.parse.urlencode(data).encode("utf-8"))
        pass
#-----------------------------------------------------------------------------------------------
#Crypt/Decrypt
#-----------------------------------------------------------------------------------------------

def crypt(data,renick):
        publickey = RSA.importKey(open("Dialogues\\"+ renick + "\\xpublickey.txt",'rb').read())
        cipherrsa = PKCS1_OAEP.new(publickey)
        secdata = cipherrsa.encrypt(data.encode("utf-8"))
        return secdata

def decrypt(secdata):
        privatekey = RSA.importKey(open('privatekey.txt','rb').read())
        cipherrsa = PKCS1_OAEP.new(privatekey)
        decdata = cipherrsa.decrypt(secdata)
        return decdata

#-----------------------------------------------------------------------------------------------
#Messages operations
#-----------------------------------------------------------------------------------------------

def startmes(renick,nick):
        data = {"message" : crypt("Hey I`m online!",str(renick)) , "nick" : nick, "chatid" : str(chatid(renick,nick)) }

        encoded_data = urllib.parse.urlencode(data).encode("utf-8")
        content = urllib.request.urlopen(c3,encoded_data)

def receivemessages(renick,nick):
        h = None
        while stop != True:
                try:
                        mes = urllib.request.urlopen(c5)
                        h2 = urllib.request.urlopen(c5).read()
                except:
                        receivemessages(renick,nick)

                if h != h2:
                        decmes = decrypt(mes.read()).decode()
                        print (b1 + b2 + renick + ":" + decmes ,end= end)
                        h = h2
        UI(nick)

def sendmessage(nick,renick):
        while stop != True:
                data = {"message" : crypt( input(UIinput(33,34)),str(renick)) , "nick" : nick , "chatid" : str(chatid(renick,nick)) }
                content = urllib.request.urlopen(c3,urllib.parse.urlencode(data).encode("utf-8"))

def check(renick,nick):
        sc = "http://hcbf.000webhostapp.com/RSA/" + renick + "/message" + str(chatid(renick,nick)) + ".txt"; h = 1 ;  h2 = 1
        receivepub(renick)
        while True:
                try:
                    h2 = urllib.request.urlopen(sc).read()
                except:
                    check(renick,nick)
                if h != h2:
                        try:
                                h = h2
                                toaster.show_toast("New message from:" + renick,
                                        decrypt(urllib.request.urlopen(sc).read()).decode(),
                                        icon_path="python.ico",
                                        duration=10)
                                while toaster.notification_active(): time.sleep(0.1)
                        except:
                                check(renick,nick)

#-----------------------------------------------------------------------------------------------
#Additional Operations
#-----------------------------------------------------------------------------------------------

def UIinput(x,y):
        return str('|--:>' + ' ' * x + '|' + '\b' * y)

def execute():
        global stop
        os.system('cls')
        stop = True
        hotkey('enter')

def notifi(nick):
        o = os.listdir(DIR)
        x = 0
        e = 0
        while e < len(o):
                i = o[e]
                print(i)
                x = threading.Thread(target=check, args=(i, nick, ))
                x.start()
                e = e + 1

def chatid(renick,nick):
        x = 0
        y = 0
        for i in renick:
                x = ord(i) + x
        for i in nick:
                y = ord(i) + y
        return x * y

def ProcRun(nick,renick):
        global stop
        stop = False

        receivepub(renick)
        startmes(renick,nick)

        t1 = threading.Thread(target=sendmessage, args=(nick,renick ))
        t2 = threading.Thread(target=receivemessages, args=(renick,nick ))

        t1.start()
        t2.start()

#-----------------------------------------------------------------------------------------------
#User Interface
#-----------------------------------------------------------------------------------------------

def UI(nick):
        global c5
        index , i = tui.dialogs()

        if index.isdigit() and int(index) in range(1,i):

                renick = os.listdir(DIR)[(int(index)-1)]
                c5 = tui.dialog(renick,nick)
                ProcRun(nick,renick)

        elif index == '99':

            renick = str(tui.createchat())
            if os.path.isdir(DIR + str(renick)):
                        c5 = tui.dialog(renick,nick)
                        ProcRun(nick,renick)
            else:
                        os.mkdir(DIR + str(renick))
                        c5 = tui.dialog(renick,nick)
                        ProcRun(nick,renick)
        else:
                UI(nick)

if __name__ == "__main__":
        nick,password = tui.login()
        print('|Please wait, we generate a pair of RSA keys|')

        keygen()
        sendpub(nick,password)

        notifica = threading.Thread(target=notifi, args=(nick, ))
        notifica.start()
        UI(nick)
