from urllib.request import *
#proxy = ProxyHandler({'https': '202.174.46.113:43562','https':'157.230.29.234:8080'})
proxy = ProxyHandler({'https': '109.69.1.16:58874'})

opener = build_opener(proxy)
install_opener(opener)
f = urlopen('https://api.ipify.org/')
print(f.read())
