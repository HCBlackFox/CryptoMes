from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from pynput import keyboard
import binascii, hashlib 
import urllib.request, urllib.parse, urllib.error, urllib.request, urllib.error, urllib.parse 
import sys, time, threading, os
import TUI as tui


#Server varibels________________________________________________


c1 = "http://hcbf.000webhostapp.com/RSA/pubrecord.php"
c2 = "http://hcbf.000webhostapp.com/RSA/chatid.php"
c3 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"
c4 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"
c5 = "http://hcbf.000webhostapp.com/RSA/message.php"
c7 = "http://hcbf.000webhostapp.com/RSA/keyexchange.php"


#______________________________________________________________


#PART 1 -------------------------------------------------------------------------------


#RSA Key operations____________________________________________



#Keypair generations___________________________________________


def keygen():
        privatekey = RSA.generate(2048)
        
        f = open('privatekey.txt','wb')
        f.write(bytes(privatekey.exportKey('PEM'))); f.close()
        
        publickey = privatekey.publickey()
        
        f = open('publickey.txt','wb')
        f.write(bytes(publickey.exportKey('PEM'))); f.close()
        
        print("Keypair generate succesfuly :)")
        pass


#--------------------


#Encryption/Decription operarions______________________________


def crypt(data,renick):
        publickey = RSA.importKey(open("Dialogues\\"+ renick + "\\xpublickey.txt",'rb').read())
        cipherrsa = PKCS1_OAEP.new(publickey)
        secdata = cipherrsa.encrypt(data.encode("utf-8"))
        return secdata



def decrypt(secdata):
        privatekey = RSA.importKey(open('privatekey.txt','rb').read())
        cipherrsa = PKCS1_OAEP.new(privatekey)
        decdata = cipherrsa.decrypt(secdata)
        return decdata


#--------------------


#Key Exchange____________________________________________________


def receivepub(nick):
        DIR = "Dialogues\\"

        name =  "1"
        data = {"user" : nick}
                        
        encoded_data = urllib.parse.urlencode(data).encode("utf-8")
        content = urllib.request.urlopen(c7,
                encoded_data)           
                        
        pubsite = urllib.request.urlopen(c4)
        pubkey = pubsite.read()
                        
        f = open(DIR + str(nick) + "\\xpublickey.txt" , 'wb')
        f.write(bytes(pubkey)); f.close();
        pass


def sendpub(nick,password):
        mypub = open('publickey.txt','rb')
                        
        name =  "1"
        data = {"pub" : mypub.read(), "nick" : nick, "pass" : password}
                        
        encoded_data = urllib.parse.urlencode(data).encode("utf-8")
        content = urllib.request.urlopen(c1,
                encoded_data)
        pass


#----------------------




#PART 2 ------------------------------------------------------------------------------------------

#HOT KEYS

def hotkeys():
        COMBINATIONS = [
            {keyboard.Key.esc}
            
        ]

        # The currently active modifiers
        current = set()

        def execute():
            username = 'developer'
            password = 'developer'
            UI(username)

        def on_press(key):
            if any([key in COMBO for COMBO in COMBINATIONS]):
                current.add(key)
                if any(all(k in current for k in COMBO) for COMBO in COMBINATIONS):
                    execute()

        def on_release(key):
            if any([key in COMBO for COMBO in COMBINATIONS]):
                current.remove(key)

        with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
            listener.join()
hk = threading.Thread(target=hotkeys)
hk.start()



#----------------------


#TUI


end ='\n|--:>                                 |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b'
b1 ='\b\b\b\b\b\b\b|'
b2 ='                                     |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b'
inp = '|--:>                                 |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b'
inp2 = '|Create new sessions keypair?(1/2)               |'


def ProcRun(c5,c6,nick,renick):
        receivepub(renick)
        startmes(renick)
        
        t1 = threading.Thread(target=sendmessage, args=(nick,c5,renick ))
        t2 = threading.Thread(target=wait, args=(c6,renick ))
    
        t1.start()
        t2.start()
        pass



def UI(nick):

        DIR = 'Dialogues/'
        index , i = tui.dialogs()
        
        if int(index) in range(0,i):

                renick = os.listdir(DIR)[(int(index)-1)]
                c6 = tui.dialog(renick)

                ProcRun(c5,c6,nick,renick)
        elif index == '99':
                
                renick = str(tui.createchat())
                c6 = tui.dialog(str(renick))

                if nick in os.listdir(DIR):
                        
                        ProcRun(c5,c6,nick,renick) 

                else:
                        
                        os.mkdir(DIR + str(renick))  
                        ProcRun(c5,c6,nick,renick) 





#-----------------------




#Receive \ Send messages__________________________________________


def startmes(renick):
        secdata = crypt("Hey send me message!:)",str(renick))
        
        name =  "1"
        data = {"message" : secdata , "nick" : nick }           
        
        encoded_data = urllib.parse.urlencode(data).encode("utf-8")
        content = urllib.request.urlopen(c5,
                encoded_data)



def wait(c6,renick):
        startmes(renick)

        try:

                h = 1
                        
                while True:
                                
                                mes = urllib.request.urlopen(c6)
                                
                                h2 = urllib.request.urlopen(c6).read()
                                
                                if h != h2:
                                
                                        decmes = decrypt(mes.read()).decode()
                                
                                        print (b1 + b2 + renick + ":" + decmes ,end=end ,flush=True)
                                        h = h2
        except:
                wait(c6,renick) 



def sendmessage(nick,c5,renick):
                while True:
                        
                        secdata = crypt(input(inp),str(renick))
                        
                        name =  "1"
                        data = {"message" : secdata , "nick" : nick }
                        
                        encoded_data = urllib.parse.urlencode(data).encode("utf-8")
                        content = urllib.request.urlopen(c5,
                                encoded_data)


#----------------------------------------------------------------------------------
#FUNC-s end












if __name__ == "__main__": 

        nick,password = tui.login()
        print('|Please wait, we generate a pair of RSA keys|')
        
        keygen()
        sendpub(nick,password)

        UI(nick)
        








