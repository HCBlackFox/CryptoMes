import os
from time import localtime, strftime





						     





def dialog(renick):
	renick = str(renick)
	c6 = "http://hcbf.000webhostapp.com/RSA/message" + renick + ".txt"

	os.system('cls')
	print(' ________________________ \n|' + '            |Local Date:|_________\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b' + renick)
	
	print('''|‾‾‾‾‾‾‾‾‾‾‾‾‾‾|	      |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b‾|‾'''  + strftime(" %Y-%m-%d %H:%M:%S|", localtime()))
	print('''|‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾_‾|''')
	return c6





	

def dialogs():
		os.system('cls')
		print('''|— Chats ————|————―''')
		DIR = 'Dialogues/'
		i = 1
		a = len(os.listdir(DIR))
		for name in os.listdir(DIR):
			print('|' + '            |\b\b\b\b\b\b\b\b\b\b\b\b' + str(i) + '.' + name )
			if i == a:
				print('|____________|________________\n' + '|---Press 99 to create a chat.|')
			i = i + 1
		index = input('|-----:>')
		return index,i

def login():
    os.system('cls')
    print('''
_____________________________________
|				    |
|  _                                |
| /_/ _  _  .  __/_ _  _            |
|/ \ /_'/_// _\ /  /_'/             |
|      _/                           |
|              _                    |
|             /_/ _  _  _     _ _/_ |
|            / / /_ /_ /_//_// //   |
|___________________________________|                                     	
_____________________________________                         ''')
    username = input('''|Username:                          |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b''')
    password = input('''|Password:                          |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b''')
    print('|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|')

    print('''|Register Successfully)             |_______''')
    return username , password


def createchat():
                renick = input("|What is your recipient's nickname  |\n|>                                  |\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b") 
                return renick

                                       
