from Crypto.Cipher.PKCS1_OAEP import new
from Crypto.PublicKey import RSA 
import hashlib, urllib.request, urllib.parse, urllib.error
from time import sleep
from os import system
from binascii import unhexlify
from re import sub
from urllib.request import urlopen


def decrypt(secdata):
	#secdata = unhexlify(sub(':', '',secdata))
	privatekey = RSA.importKey(open('privatekey.txt','rb').read())
	cipherrsa = new(privatekey)
	decdata = cipherrsa.decrypt(secdata)
	return decdata


def wait(prevmes):
	while True:
		mes = urlopen(c6)
		print('1')
		if prevmes != mes:
			system('cls')
			print (decrypt(mes.read()).decode())
			receivemessage()
	



def receivemessage():
	while True:
		sleep(1)
		mes = urlopen(c6)
		wait(mes)

renick = input("What is your recipient's nickname\n:>") 

c1 = "http://hcbf.000webhostapp.com/RSA/pubrecord.php"#1
c2 = "http://hcbf.000webhostapp.com/RSA/chatid.php"#1
c3 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
c4 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
c5 = "http://hcbf.000webhostapp.com/RSA/message.php"#-
c6 = "http://hcbf.000webhostapp.com/RSA/message" + renick + ".txt"
c7 = "http://hcbf.000webhostapp.com/RSA/keyexchange.php"


receivemessage()