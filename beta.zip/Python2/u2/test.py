from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA 
import hashlib, urllib
from time import sleep
from os import system
from binascii import unhexlify
from re import sub
from urllib import urlopen


def decrypt(secdata):
	secdata = unhexlify(sub(':', '',secdata))
	privatekey = RSA.importKey(open('privatekey.txt','rb').read())
	cipherrsa = PKCS1_OAEP.new(privatekey)
	decdata = cipherrsa.decrypt(secdata)
	return decdata






def receivemessage():
	mesfile =  open("mes.txt","wb+")
	while True:
		sleep(1)
		system('cls')
		try:
			cryptmes = urlopen(c6)
			mes = cryptmes.read()
			if mes != mesfile.read():
					mesfile.write(decrypt(mes))
					if mes != '':
							print decrypt(mes)

		except:
			receivemessage()
renick = raw_input("What is your recipient's nickname\n:>") 

c1 = "http://hcbf.000webhostapp.com/RSA/pubrecord.php"#1
c2 = "http://hcbf.000webhostapp.com/RSA/chatid.php"#1
c3 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
c4 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
c5 = "http://hcbf.000webhostapp.com/RSA/message.php"#-
c6 = "http://hcbf.000webhostapp.com/RSA/message" + renick + ".txt"
c7 = "http://hcbf.000webhostapp.com/RSA/keyexchange.php"


receivemessage()