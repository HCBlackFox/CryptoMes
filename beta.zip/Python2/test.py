from Crypto.Cipher.PKCS1_OAEP import new
from Crypto.PublicKey import RSA 
import hashlib, urllib
from time import sleep
from os import system
from binascii import unhexlify
from re import sub
from urllib import urlopen


def decrypt(secdata):
	secdata = unhexlify(sub(':', '',secdata))
	privatekey = importKey(open('privatekey.txt','rb').read())
	cipherrsa = new(privatekey)
	decdata = cipherrsa.decrypt(secdata)
	return decdata






def receivemessage():
	while True:
		sleep(1)
		system('cls')
		try:
			mes = urlopen(c6)
			print mes.read()
			print decrypt(mes.read())
		except:
			receivemessage()
renick = raw_input("What is your recipient's nickname\n:>") 

c1 = "http://hcbf.000webhostapp.com/RSA/pubrecord.php"#1
c2 = "http://hcbf.000webhostapp.com/RSA/chatid.php"#1
c3 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
c4 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
c5 = "http://hcbf.000webhostapp.com/RSA/message.php"#-
c6 = "http://hcbf.000webhostapp.com/RSA/message" + renick + ".txt"
c7 = "http://hcbf.000webhostapp.com/RSA/keyexchange.php"


receivemessage()