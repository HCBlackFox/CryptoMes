from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from termcolor import colored
import binascii, re, hashlib, urllib, urllib2, os, multiprocessing

def keygen():
			
			privatekey = RSA.generate(2048)
			f = open('privatekey.txt','wb')
			f.write(bytes(privatekey.exportKey('PEM'))); f.close()
			publickey = privatekey.publickey()
			f = open('publickey.txt','wb')
			f.write(bytes(publickey.exportKey('PEM'))); f.close()
			print("Keys generate succesfuly :)")
			pass


def crypt(data):
			publickey = RSA.importKey(open("xpublickey.txt",'rb').read())
			cipherrsa = PKCS1_OAEP.new(publickey)
			secdata = cipherrsa.encrypt(data)
			secdata = ":".join("{:02x}".format(ord(c)) for c in secdata)
			return secdata





def decrypt(secdata):
			secdata = binascii.unhexlify(re.sub(':', '',secdata))
			privatekey = RSA.importKey(open('privatekey.txt','rb').read())
			cipherrsa = PKCS1_OAEP.new(privatekey)
			print secdata
			decdata = cipherrsa.decrypt(secdata)
			return decdata



def receivepub(nick):
			
			name =  "1"
			data = {"user" : nick}
			
			encoded_data = urllib.urlencode(data)
			content = urllib2.urlopen(c7,
		        encoded_data)		
			
			pubsite = urllib.urlopen(c4)
			pubkey = pubsite.read()
			
			f = open('xpublickey.txt','wb')
			f.write(bytes(pubkey)); f.close();



def sendpub(nick,password):
			mypub = open('publickey.txt','rb')
			
			name =  "1"
			data = {"pub" : mypub.read(), "nick" : nick, "pass" : password}
			
			encoded_data = urllib.urlencode(data)
			content = urllib2.urlopen(c1,
		        encoded_data)	
			


def sendmessage(nick):
		while True:
			secdata = crypt(raw_input("Messege:"))
			
			name =  "1"
			data = {"message" : secdata , "nick" : nick }
			
			encoded_data = urllib.urlencode(data)
			content = urllib2.urlopen(c5,
	        	encoded_data)




#___________________________________________________________________________________________________________________________
if __name__ == "__main__": 


			nick = raw_input('What is your nickname? \n:>')

			password = raw_input('What is your password? \n:>')

			renick = raw_input("What is your recipient's nickname\n:>") 

			key = raw_input("Generate RSA keys? \n:>")

			if key == '1':
				keygen()


			#sys = raw_input("Which channel to use?(1/2) \n:>")
			#if sys == '1':
			c1 = "http://hcbf.000webhostapp.com/RSA/pubrecord.php"#1
			c2 = "http://hcbf.000webhostapp.com/RSA/chatid.php"#1
			c3 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
			c4 = "http://hcbf.000webhostapp.com/RSA/publickey.txt"#1
			c5 = "http://hcbf.000webhostapp.com/RSA/message.php"#-
			c6 = "http://hcbf.000webhostapp.com/RSA/message" + renick + ".txt"
			c7 = "http://hcbf.000webhostapp.com/RSA/keyexchange.php"
			'''
			if sys == '2':
					c1 = "http://hcbf.000webhostapp.com/RSA2/pubrecord.php"
					c2 = "http://hcbf.000webhostapp.com/RSA2/chatid.php"
					c3 = "http://hcbf.000webhostapp.com/RSA2/publickey.txt"
					c4 = "http://hcbf.000webhostapp.com/RSA2/publickey.txt"
					c5 = "http://hcbf.000webhostapp.com/RSA2/message.php"
					c6 = "http://hcbf.000webhostapp.com/RSA2/message" + renick + ".txt"
					c7 = "http://hcbf.000webhostapp.com/RSA2/keyexchange.php"
			'''

			key = raw_input("You want to send publickey? \n:>")

			if key == '1':
				sendpub(nick,password)

			key = raw_input("You want to receive publickey? \n:>")

			if key == '1':
					receivepub(renick)

			sendmessage(nick) 
					
