from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
from termcolor import colored
import binascii, re, hashlib, urllib, urllib2, os, time , multiprocessing, base64



def crypt(data):
	publickey = RSA.importKey(open("xpublickey.txt",'rb').read())
	cipherrsa = PKCS1_OAEP.new(publickey)
	secdata = cipherrsa.encrypt(data)
	secdata = ":".join("{:02x}".format(ord(c)) for c in secdata)
	return secdata





def decrypt(secdata):
	secdata = binascii.unhexlify(re.sub(':', '',secdata))
	privatekey = RSA.importKey(open('privatekey.txt','rb').read())
	cipherrsa = PKCS1_OAEP.new(privatekey)
	decdata = cipherrsa.decrypt(secdata)
	return decdata



import requests # $ python -m pip install requests
####from pip._vendor import requests # bundled with python

url = 'http://hcbf.000webhostapp.com/RSA2/1.txt'
user = 'python'
password = '8i3e5t2w0p9o4r0p6y8i0p8i'


r = requests.get(url, auth=(user, password)) # send auth unconditionally
print r.text # raise an exception if the authentication fails


	

